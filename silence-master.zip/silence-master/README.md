# Silence
A simple, clean macro recorder written in C#. Windows 10 compatible.

## Acknowledgements
It's been a while since I re-created this repo and managed to lose the readme in the process (completely forgot about it), so if make any mistakes/ommissions with attribution/copyright notices for anyone, please do not hesitate to contact me and I'll put it right.

* The original [HookLib](https://github.com/codelogic/HookLib) by [Paul Rhode](https://github.com/codelogic).
* The original [Input Simulator](https://github.com/michaelnoonan/inputsimulator/) by [Michael Noonan](https://github.com/michaelnoonan/).
