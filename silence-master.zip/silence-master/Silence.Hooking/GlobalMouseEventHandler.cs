using System;

namespace Silence.Hooking
{

    public delegate void GlobalMouseEventHandler(object sender, GlobalMouseEventHandlerArgs args);

}
