using System;

namespace Silence.Hooking
{

    public delegate void GlobalKeyEventHandler(object sender, GlobalKeyEventHandlerArgs args);

}
